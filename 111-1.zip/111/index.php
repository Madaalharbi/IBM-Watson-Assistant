<?php
$servername = "localhost";
$username = "root";
$password = "";
$db ="robot_db";

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error)
  die("Connection failed: " . $conn->connect_error);
else
  echo "Connected successfully";

  $db_select = mysqli_select_db( $conn, 'robot_db' );
  if (!$db_select) {
    die("Database selection also failed miserably: " . mysql_error());
  }

  if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    echo '<div class="result">';
		if (isset($_POST['partone'])) {
      $x1 = $_POST['Motor1'];
      $x2 = $_POST['Motor2'];
      $x3 = $_POST['Motor3'];
      $x4 = $_POST['Motor4'];
      $x5 = $_POST['Motor5'];
      $x6 = $_POST['Motor6'];
        $sql = "INSERT INTO motors (motor1, motor2, motor3, motor4, motor5, motor6) VALUES (". $x1 .",". $x2 .",". $x3 .",". $x4 .",". $x5 .",". $x6 .")";
        if ($conn->query($sql) === TRUE) {
          echo "<br>Saved successfully";
        } else {
          echo "Error: " . $sql . "<br>" . $conn->error;
        }
        $conn->close();
    }
    else if (isset($_POST['parttwo'])) {
      $sql = "SELECT * FROM motors ORDER BY id DESC LIMIT 1";
      $result = $conn->query($sql);
      if (mysqli_num_rows($result)) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
          echo "<br>motor1: " . $row["motor1"];
          echo "<br>motor2: " . $row["motor2"];
          echo "<br>motor3: " . $row["motor3"];
          echo "<br>motor4: " . $row["motor4"];
          echo "<br>motor5: " . $row["motor5"];
          echo "<br>motor6: " . $row["motor6"];
        }
      } else {
        echo "0 results";
      }
      $conn->close();
    }
    
    echo '</div>';
  }

?>

<!DOCTYPE html>
<html>
<link rel="stylesheet" href="style.css">

<head>
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Robot Control Panel</title>
</head>
<body>
<h1>Robot Control Panel</h1>

<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST">
<div class="slidecontainer">
<p>
<label> Motor 1</label>
  <input type="range" min="0" max="180" value="50" class="slider" id="motor1" name="Motor1">
  <p >Value: <span id="demo" ></span></p>
  <p>
</div>

<script>
var slider_1 = document.getElementById("motor1");
var output_1 = document.getElementById("demo");
output_1.innerHTML = slider_1.value;

slider_1.oninput = function() {
  output_1.innerHTML = this.value;
}
</script>
<div class="slidecontainer">
<p>
<label> Motor 2</label>
  <input type="range" min="0" max="180" value="50" class="slider" id="motor2" name="Motor2">
  <p>Value: <span id="demo1"></span></p>
  </p>
</div>

<script>
var slider_2 = document.getElementById("motor2");
var output_2 = document.getElementById("demo1");
output_2.innerHTML = slider_1.value;

slider_2.oninput = function() {
  output_2.innerHTML = this.value;
}
</script>
<div class="slidecontainer">
<p>
<label> Motor 3</label>
  <input type="range" min="0" max="180" value="50" class="slider" id="motor3" name="Motor3">
  <p>Value: <span id="demo3"></span></p>
  </p>
</div>

<script>
var slider_3 = document.getElementById("motor3");
var output_3 = document.getElementById("demo3");
output_3.innerHTML = slider_3.value;

slider_3.oninput = function() {
  output_3.innerHTML = this.value;
}
</script>

<div class="slidecontainer">
<p>
<label> Motor 4</label>
  <input type="range" min="0" max="180" value="50" class="slider" id="motor4" name="Motor4">
  <p>Value: <span id="demo4"></span></p>
  </p>
</div>

<script>
var slider_4 = document.getElementById("motor4");
var output_4 = document.getElementById("demo4");
output_4.innerHTML = slider_4.value;

slider_4.oninput = function() {
  output_4.innerHTML = this.value;
}
</script>

<div class="slidecontainer">
<p>
<label> Motor 5</label>
  <input type="range" min="0" max="180" value="50" class="slider" id="motor5" name="Motor5">
  <p>Value: <span id="demo5"></span></p>
  </p>
</div>

<script>
var slider_5 = document.getElementById("motor5");
var output_5 = document.getElementById("demo5");
output_5.innerHTML = slider_5.value;

slider_5.oninput = function() {
  output_5.innerHTML = this.value;
}
</script>
<div class="slidecontainer">
<p>
<label> Motor 6</label>
  <input type="range" min="0" max="180" value="50" class="slider" id="motor6" name="Motor6">
  <p>Value: <span id="demo6"></span></p>
  </p>
</div>

<script>
var slider_6 = document.getElementById("motor6");
var output_6 = document.getElementById("demo6");
output_6.innerHTML = slider_6.value;

slider_6.oninput = function() {
  output_6.innerHTML = this.value;
}
</script>

<button class="button button1" name="partone" type="submit">Save</button>
<button class="button button2" name="parttwo" type="submit">Run</button>
</form>



<script>
  window.watsonAssistantChatOptions = {
      integrationID: "c3b0ffae-c09f-4516-b831-79ddb03c56d1", // The ID of this integration.
      region: "eu-de", // The region your integration is hosted in.
      serviceInstanceID: "c3dcc296-500d-4d3d-831b-8bd7469e56e2", // The ID of your service instance.
      onLoad: function(instance) { instance.render(); }
    };
  setTimeout(function(){
    const t=document.createElement('script');
    t.src="https://web-chat.global.assistant.watson.appdomain.cloud/loadWatsonAssistantChat.js";
    document.head.appendChild(t);
  });
</script>

</body>


</html>