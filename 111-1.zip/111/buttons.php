<?php
$servername = "localhost";
$username = "root";
$password = "";
$db ="robot_db";

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error)
  die("Connection failed: " . $conn->connect_error);
else
  echo "Connected successfully";

  $db_select = mysqli_select_db( $conn, 'robot_db' );
  if (!$db_select) {
    die("Database selection also failed miserably: " . mysql_error());
  }

  if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    echo '<div class="result">';
		if (isset($_POST['partone'])) {
      $x1 = $_POST['Motor1'];
      $x2 = $_POST['Motor2'];
      $x3 = $_POST['Motor3'];
      $x4 = $_POST['Motor4'];
      $x5 = $_POST['Motor5'];
      $x6 = $_POST['Motor6'];
        $sql = "INSERT INTO motors (motor1, motor2, motor3, motor4, motor5, motor6) VALUES (". $x1 .",". $x2 .",". $x3 .",". $x4 .",". $x5 .",". $x6 .")";
        if ($conn->query($sql) === TRUE) {
          echo "<br>Saved successfully";
        } else {
          echo "Error: " . $sql . "<br>" . $conn->error;
        }
        $conn->close();
    }
    else if (isset($_POST['parttwo'])) {
      $sql = "SELECT * FROM motors ORDER BY id DESC LIMIT 1";
      $result = $conn->query($sql);
      if (mysqli_num_rows($result)) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
          echo "<br>motor1: " . $row["motor1"];
          echo "<br>motor2: " . $row["motor2"];
          echo "<br>motor3: " . $row["motor3"];
          echo "<br>motor4: " . $row["motor4"];
          echo "<br>motor5: " . $row["motor5"];
          echo "<br>motor6: " . $row["motor6"];
        }
      } else {
        echo "0 results";
      }
      $conn->close();
    }
    
    echo '</div>';
  }

?>

<!DOCTYPE html>
<html>
<link rel="stylesheet" href="style.css">

<head>
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Robot Control Panel</title>
</head>
<body>
<h1>Robot Control Panel</h1>

<div class="center">
<form action="buttonsave.php" method="POST">
<input type="submit" class="button button2" id="buttonmove" name="Forward" value="Forward"><br>
<input type="submit" class="button button2" id="buttonmove" name="Left" value="Left">
<input type="submit" class="button button2" id="buttonmove" name="Stop" value="Stop">
<input type="submit" class="button button2" id="buttonmove" name="Right" value="Right"><br>
<input type="submit" class="button button2" id="buttonmove" name="Backword" value="Backword">

  <!-- <input type="hidden" id="buttonmove" name="buttonmove" value="">
  <button type="submit" name="Forward" onclick="buttonmove('Forward')" class="button button2">Forward</button>
  <br>
  <button type="submit" name="Left" onclick="buttonmove('Left')" class="button button2">Left</button>
  <button type="submit" name="Stop" onclick="buttonmove('Stop')" class="button button2">Stop</button>
  <button type="submit" name="Right" onclick="buttonmove('Right')" class="button button2">Right</button>
  <br>
  <button type="submit" name="Backword" onclick="buttonmove('Backword')" class="button button2">Backword</button> -->
</form>
</div>

<script>
  window.watsonAssistantChatOptions = {
      integrationID: "c3b0ffae-c09f-4516-b831-79ddb03c56d1", // The ID of this integration.
      region: "eu-de", // The region your integration is hosted in.
      serviceInstanceID: "c3dcc296-500d-4d3d-831b-8bd7469e56e2", // The ID of your service instance.
      onLoad: function(instance) { instance.render(); }
    };
  setTimeout(function(){
    const t=document.createElement('script');
    t.src="https://web-chat.global.assistant.watson.appdomain.cloud/loadWatsonAssistantChat.js";
    document.head.appendChild(t);
  });
</script>

</body>


</html>