<?php
$servername = "localhost";
$username = "root";
$password = "";
$db ="robot_db";

// Create connection
$conn = new mysqli($servername, $username, $password);
$db_select = mysqli_select_db( $conn, 'robot_db' );

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    if (isset($_POST['Forward']))
        $x1 = $_POST['Forward'];
    else if (isset($_POST['Left']))
        $x1 = $_POST['Left'];
    else if (isset($_POST['Stop']))
        $x1 = $_POST['Stop'];
    else if (isset($_POST['Right']))
        $x1 = $_POST['Right'];
    if (isset($_POST['Backword']))
        $x1 = $_POST['Backword'];
        
    $sql = "INSERT INTO buttonmove (name) VALUES ('". $x1 ."')";
    if ($conn->query($sql) === TRUE) {
        $message =  "<br><h3>Saved successfully ===> " . $x1 . "</h3>";
    } else {
        $message =  "Error: " . $sql . "<br>" . $conn->error;
    }
    $conn->close();
}
?>

<!doctype html>
<html>
  <head>
    <title>Robot Control Panel</title>
    <link rel="stylesheet" href="style.css">
  </head>
  <body>
  <h1>Robot Control Panel</h1>
    <?php
        if (isset($message))
            echo $message;
    ?>
	
<script>
  window.watsonAssistantChatOptions = {
      integrationID: "c3b0ffae-c09f-4516-b831-79ddb03c56d1", // The ID of this integration.
      region: "eu-de", // The region your integration is hosted in.
      serviceInstanceID: "c3dcc296-500d-4d3d-831b-8bd7469e56e2", // The ID of your service instance.
      onLoad: function(instance) { instance.render(); }
    };
  setTimeout(function(){
    const t=document.createElement('script');
    t.src="https://web-chat.global.assistant.watson.appdomain.cloud/loadWatsonAssistantChat.js";
    document.head.appendChild(t);
  });
</script>
  </body>
</html>